package com.spring.admin.dao;

import com.spring.admin.vo.AdminVo;

public interface AdminDao {

	// 관리자 로그인
	void login(AdminVo adminVo);
}
